#ifndef __CREDENTIALS_H__
#define __CREDENTIALS_H__

// Wifi parameters
char passphrase[] = "passphrase";
char ssid[] = "ssid";

#endif

