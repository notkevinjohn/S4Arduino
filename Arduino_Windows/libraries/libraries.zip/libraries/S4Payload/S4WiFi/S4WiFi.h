#ifndef  __S4WIFI_H__
#define __S4WIFI_H__

#include "S4WiFiDevice.h"
#include "../WiFly/WiFly.h"

extern WiFlyDevice WiFly;

#endif
