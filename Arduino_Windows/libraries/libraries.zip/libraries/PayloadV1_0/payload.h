#ifndef PAYLOAD_H
#define PAYLOAD_H

#include <Arduino.h>
#include <WProgram.h>

class PAYLOAD {
public:
       PAYLOAD();
       ~PAYLOAD();
};
#endif
